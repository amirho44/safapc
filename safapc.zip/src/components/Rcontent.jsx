import React, { Component } from 'react';
import './content.css'

class Rcontent extends Component {
    render() {
        return (
            <div className='content'>

                <div className='textbox'>
                    <p>

                        architecto ab laudantium
                        modi minima sunt esse temporibus sint culpa, recusandae aliquam numquam
                        totam ratione voluptas quod exercitationem fuga. Possimus quis earum veniam
                        quasi aliquam eligendi, placeat qui corporis!
                    </p>

                </div>

            </div>
        );
    }
}

export default Rcontent;