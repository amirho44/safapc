// import React, { Component } from 'react';
// import '../App.css'
// import { Route } from 'react-router-dom';
// import Header from '../components/Header';
// import Sidebar from '../components/Sidebar';


// class Dashboard2 extends Component {

//     render() {
//         return (
//             <div>
//                 <Header />
//                 <Sidebar />
//                 <h1>hellotest</h1>
//             </div>
//         );
//     }
// }

// export default Dashboard2;